#! /bin/bash

apt-get install portaudio19-dev ffmpeg wget -y
