import os
from galaxy_ie_helpers import get
from galaxy_ie_helpers import put
from galaxy_ie_helpers import get_galaxy_connection
HISTORY_ID = os.environ.get('HISTORY_ID', None)
